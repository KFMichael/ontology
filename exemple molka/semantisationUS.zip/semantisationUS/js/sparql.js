
	
	function findDetailsUS(usId){
		<!-- rows will go here -->
		  var url = "http://localhost:3030/data/query";
		  //il ne faut pas mettre le caractere # , mais %23 a la place
		  
		  var query = "\PREFIX User-Stories: <http://www.exemple.fr/usersstory.rdfs%23> "+
		  "PREFIX Metier: <http://www.exemple.fr/university.rdfs%23>"+
		 " SELECT distinct ?name ?state ?priority ?effort ?businessDomain ?whoAction ?whatCode ?whatVerbe ?whatObject ?whatParam ?whyCode ?whyVerbe ?whyObject ?whyParam"+
		 " WHERE { "+
		 " ?US  User-Stories:name  ?name;"+
		 " User-Stories:hasState ?state;"+
		 " User-Stories:hasPriority ?priority;"+
		 " User-Stories:hasEffort ?effort;"+
		 " User-Stories:hasbussinessDomain ?businessDomain;"+
		 " User-Stories:hasDimension ?whoDimension;"+
		 " User-Stories:hasDimension ?whatDimension."+
		 " ?whoDimension a User-Stories:WhoDimension."+
		 " ?whoDimension User-Stories:hasRole ?whoAction."+
		 " ?whatDimension a User-Stories:WhatDimension."+
		 " ?whatDimension User-Stories:hasWhatAction ?whatAction."+
		 " ?whatAction a ?whatCode."+
		 " ?whatAction User-Stories:definedBy ?whatIntention."+
		 " ?whatIntention User-Stories:hasVerbe ?whatVerbe."+
		 " ?whatIntention User-Stories:hasObject ?whatObject."+
		 " OPTIONAL{?whatIntention User-Stories:hasParameter ?whatParam.}"+
		 " OPTIONAL{ ?US User-Stories:hasDimension ?whyDimension."+
		 " ?whyDimension a User-Stories:WhyDimension."+
		 " ?whyDimension User-Stories:hasWhyAction ?whyAction."+
		 " ?whyAction a ?whyCode."+
		 " ?whyAction User-Stories:definedBy ?whyIntention."+
		 " ?whyIntention User-Stories:hasVerbe ?whyVerbe."+
		 " ?whyIntention User-Stories:hasObject ?whyObject."+
		 " ?whyIntention User-Stories:hasParameter ?whyParam}."+
		 " FILTER regex (?name , '"+usId+"')"+
		 " }";

		var queryUrl = url+"?query="+query+"&format=json" ;

		 $.ajax({
			dataType: "jsonp",
			url: queryUrl,
			success: function( _data ) {
				var results = _data.results.bindings;
				if(results.length > 0){
					$('#IDUS').val(results[0].name.value);
				    $('#priority').val(results[0].priority.value);
					$('#effort').val(results[0].effort.value);
					$('#state').val(results[0].state.value);
					$('#Business_Domain').val(formatInput(results[0].businessDomain.value));
					$('#role').val(formatInput(results[0].whoAction.value));
					$('#whatAction').val(formatInput(results[0].whatCode.value));
					$('#whatVerbe').val(formatInput(results[0].whatVerbe.value));
					$('#whatObject').val(formatInput(results[0].whatObject.value));
					if(results[0].whatParam != null){
						$('#whatParam').val(results[0].whatParam.value);
					} else {
						$('#whatParam').val('');
					}
					if(results[0].whyCode != null){
						$('#whyAction').val(formatInput(results[0].whyCode.value));
					} else {
						$('#whyAction').val('');
					}
					if(results[0].whyVerbe != null){
						$('#whyVerbe').val(formatInput(results[0].whyVerbe.value));
					} else {
						$('#whyVerbe').val('');
					}
					if(results[0].whyObject != null){
						$('#whyObject').val(formatInput(results[0].whyObject.value));
					} else {
						$('#whyObject').val('');
					}
					if(results[0].whyParam != null){
						$('#whyParam').val(formatInput(results[0].whyParam.value));
					} else {
						$('#whyParam').val('');
					}
				}
			}
		});
		 
	}
	
	function formatInput(input){
		return input.substring(input.indexOf("#")+1);
	}
	
	function listeDetailsUS (){
		  // Empty content string
		  var tableContent = '';
		  tableContent +='<thead><tr> <br/>\
			<td>Name</td><td>Priority</td><td>Effort</td><td>State</td><td>BusinessDomain</td><td>Description</td><td>Actions</td>\
			</tr></thead>';;
			tableContent += '<tbody>'
			
			<!-- rows will go here -->
		  var url = "http://localhost:3030/data/query";
		  //il ne faut pas mettre le caractere # , mais %23 a la place
		  
		  var query = "\PREFIX User-Stories: <http://www.exemple.fr/usersstory.rdfs%23> "+
		  "PREFIX Metier: <http://www.exemple.fr/university.rdfs%23>"+
		 " SELECT distinct ?name ?state ?priority ?effort ?bussinessDomain ?whoAction ?whatVerbe ?whatObject ?whatParam ?whyVerbe ?whyObject ?whyParam"+
		 " WHERE { "+
		 " ?US  User-Stories:name  ?name;"+
		 " User-Stories:hasState ?state;"+
		 " User-Stories:hasPriority ?priority;"+
		 " User-Stories:hasEffort ?effort;"+
		 " User-Stories:hasbussinessDomain ?bussinessDomain;"+
		 " User-Stories:hasDimension ?whoDimension;"+
		 " User-Stories:hasDimension ?whatDimension."+
		 " ?whoDimension a User-Stories:WhoDimension."+
		 " ?whoDimension User-Stories:hasRole ?whoAction."+
		 " ?whatDimension a User-Stories:WhatDimension."+
		 " ?whatDimension User-Stories:hasWhatAction ?whatAction."+
		 " ?whatAction User-Stories:definedBy ?whatIntention."+
		 " ?whatIntention User-Stories:hasVerbe ?whatVerbe."+
		 " ?whatIntention User-Stories:hasObject ?whatObject."+
		 " OPTIONAL{?whatIntention User-Stories:hasParameter ?whatParam.}"+
		 " OPTIONAL{ ?US User-Stories:hasDimension ?whyDimension."+
		 " ?whyDimension a User-Stories:WhyDimension."+
		 " ?whyDimension User-Stories:hasWhyAction ?whyAction."+
		 " ?whyAction User-Stories:definedBy ?whyIntention."+
		 " ?whyIntention User-Stories:hasVerbe ?whyVerbe."+
		 " ?whyIntention User-Stories:hasObject ?whyObject."+
		 " ?whyIntention User-Stories:hasParameter ?whyParam}.";
		 
		  if( $('#searchpriority').val() ) { 
			query += " ?US User-Stories:hasPriority '"+$('#searchpriority').val()+"'.";
		  }
		   
		  if( $('#searcheffort').val() ) { 
			query += " ?US User-Stories:hasEffort '"+$('#searcheffort').val()+"'.";
		  }
		  if( $('#searchstate').val() ) { 
			query += " ?US User-Stories:hasState '"+$('#searchstate').val()+"'.";
		  }
		  
		  if( $('#searchbusiness_Domain').val() ) { 
			query += " ?US User-Stories:hasbussinessDomain Metier:"+$('#searchbusiness_Domain').val()+".";
		  }
		  
		  if( $('#searchrole').val() ) { 
				  query += " ?whoDimension User-Stories:hasRole Metier:"+$('#searchrole').val()+".";
		  }
		  
		  if($('#searchwhatAction').val()){
			query += "	 ?whatAction a User-Stories:"+$('#searchwhatAction').val()+".";
		  }
		  if($('#searchwhatVerbe').val() ){
				query += " ?whatIntention User-Stories:hasVerbe Metier:"+$('#searchwhatVerbe').val()+".";
		  }
		  if($('#searchwhatObject').val() ){
				query += " ?whatIntention User-Stories:hasObject Metier:"+$('#searchwhatObject').val()+".";
		  }
		  
		  if($('#searchwhyAction').val()){
			  query += "	 ?whyAction a User-Stories:"+$('#searchwhyAction').val()+".";
		  }
		  if($('#searchwhyVerbe').val() ){
			  query += " ?whyIntention User-Stories:hasVerbe Metier:"+$('#searchwhyVerbe').val()+".";
		  }
		  if($('#searchwhyObject').val() ){
			  query += " ?whyIntention User-Stories:hasObject Metier:"+$('#searchwhyObject').val()+".";
		  }
			
		query += " }";
		//var queryUrl = encodeURI( url+"?query="+query+"&format=json" );
		var queryUrl = url+"?query="+query+"&format=json" ;

		 $.ajax({
		dataType: "jsonp",
		url: queryUrl,
		success: function( _data ) {
		var results = _data.results.bindings;
		sparqlItemsData = _data;
		for ( var i in results ) {
			 tableContent += '<tr>';
			 tableContent += '<td>' + results[i].name.value + '</td>'; 
			 tableContent += '<td>' + results[i].priority.value + '</td>';
			 tableContent += '<td>' + results[i].effort.value + '</td>';
			 tableContent += '<td>' + results[i].state.value + '</td>';
			 tableContent += '<td>' + formatDimension(results[i].bussinessDomain.value) + '</td>';
			 tableContent += '<td>' + 'As a '+ formatDimension(results[i].whoAction.value) + '<br>';
			 tableContent += 'I want to '+ dimension(results[i].whatVerbe , results[i].whatObject , results[i].whatParam) + '<br>';
			 tableContent +=   'So That '+ dimension(results[i].whyVerbe , results[i].whyObject , results[i].whyParam) + '</td>';
			 tableContent += '<td><a href=\'#\' class=\'linkupdateitem\' rel=\'' + results[i].name.value + '\'>Update</a><br>';
			 tableContent += '<a href=\'#\' class=\'linkdeleteitem\' rel=\'' +  results[i].name.value  + '\'>Delete</a><br>';
			 tableContent += '<a href=\'#\' class=\'linkdepsitem\' rel=\'' +  results[i].name.value  + '\'>Links</a><br></td>';
			 tableContent += '</tr>'
		}
			//alert(tableContent);
			tableContent += '</tbody>'
			if(results.length>0){
				$('#sparqlDetailsItemList').html(tableContent);
			}else {
				$('#sparqlDetailsItemList').html('Aucun US trouvé');
			}
			$('#sparqlDetailsItemList tbody td a.linkdeleteitem').bind('click', deleteUS);
			$('#sparqlDetailsItemList tbody td a.linkupdateitem').bind('click', updateDetailsUS);
			$('#sparqlDetailsItemList tbody td a.linkdepsitem').bind('click', depsDetail);
		}
		});	


	}
	

	function listeEpicUS (){
		  // Empty content string
		  var tableContent = '';
		  tableContent +='<thead><tr> <br/>\
			<td>Name</td><td>Actions</td>\
			</tr></thead>';;
			tableContent += '<tbody>'
			
			<!-- rows will go here -->
		  var url = "http://localhost:3030/data/query";
		  //il ne faut pas mettre le caractere # , mais %23 a la place
		  
		  var query = "\PREFIX User-Stories: <http://www.exemple.fr/usersstory.rdfs%23> "+
		  "PREFIX Metier: <http://www.exemple.fr/university.rdfs%23>"+
		 " SELECT distinct ?name "+
		 " WHERE { "+
		 " ?US  a User-Stories:EpicUserStory;"+
		 "	  User-Stories:name  ?name;"+
		 "}";
		 
		//var queryUrl = encodeURI( url+"?query="+query+"&format=json" );
		var queryUrl = url+"?query="+query+"&format=json" ;

		 $.ajax({
		dataType: "jsonp",
		url: queryUrl,
		success: function( _data ) {
		var results = _data.results.bindings;
		sparqlItemsData = _data;
		for ( var i in results ) {
			 tableContent += '<tr>';
			 tableContent += '<td>' + results[i].name.value + '</td>'; 
			 tableContent += '<td><a href=\'#\' class=\'linkdeleteitem\' rel=\'' +  results[i].name.value  + '\'>Delete</a><br>';
			 tableContent += '<a href=\'#\' class=\'linkdepsitem\' rel=\'' +  results[i].name.value  + '\'>Links</a></td>';
			 tableContent += '</tr>'
			 
		}
			//alert(tableContent);
			tableContent += '</tbody>'
			$('#sparqlEpicItemList').html(tableContent);
			$('#sparqlEpicItemList tbody td a.linkdeleteitem').bind('click', deleteUS);
			$('#sparqlEpicItemList tbody td a.linkdepsitem').bind('click', depsEpic);
			$('#sparqlEpicItemList tbody td a.linkdepsitem').bind('click', depsEpic);
		}
		});	
	}
	
	function depsEpic(){
		event.preventDefault();
		$( "#sparqlChidrenItemList" ).empty();
		$( "#sparqlFatherItemList" ).empty();
		$( "#sparqlDepsItemList" ).empty();
		
		var deptitle = $(this).attr('rel');
		searchDependence(deptitle,true);
		
		$( "#thedialog" ).dialog('option','title', deptitle).dialog('open');
	}
	
	function depsDetail(event){
		event.preventDefault();
		$( "#sparqlChidrenItemList" ).empty();
		$( "#sparqlFatherItemList" ).empty();
		$( "#sparqlDepsItemList" ).empty();
		var deptitle = $(this).attr('rel');
		searchDependence(deptitle,false);
		
		$( "#thedialog" ).dialog('option','title', deptitle).dialog('open');
		
	}

	function dimension(verb,object,param){
		var dimension ='';
		if(verb != null && typeof verb != undefined){
			dimension += ' ' + formatDimension(verb.value);
		}
		if(object != null && typeof object != undefined){
			dimension += ' ' + formatDimension(object.value);
		}
		if(param != null && typeof param != undefined){
			dimension += ' ' + formatDimension(param.value);
		}
		return dimension;
	}	

	function formatDimension(dimension){
		return dimension.substring(dimension.indexOf("#")); 
	}		
				

	
	function searchDependence(usId,isEpic){
		if(isEpic){
			listeChidrenDecomps(usId);
		}
		listeFatherDecomps(usId);
		listeDeps(usId);
	}
	
		function listeChidrenDecomps (usId){
		  var tableContent = '';
		  tableContent +='<thead><tr> <br/>\
			<td> Children links</td>\
			</tr></thead>';;
			tableContent += '<tbody>'
			var countChidren = 0;
			<!-- rows will go here -->
		  var url = "http://localhost:3030/data/query";
		  //il ne faut pas mettre le caractere # , mais %23 a la place
		  
			  var query1 = "\PREFIX User-Stories: <http://www.exemple.fr/usersstory.rdfs%23> "+
				  "PREFIX Metier: <http://www.exemple.fr/university.rdfs%23>"+
				  "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema%23>"+
				 " SELECT  ?dep ?name2 "+
				 " WHERE { "+
				 " ?US ?dep ?US2."+
				 " ?dep rdfs:subPropertyOf User-Stories:isDecomposed."+
				 " ?US  User-Stories:name  '"+usId+"'."+	 
				 " ?US2 User-Stories:name ?name2."+
				  " FILTER (!regex( str(?dep) ,  'isDecomposed' ))"+
				 "}";
				 
			 var queryUrl = url+"?query="+query1+"&format=json" ;
			 $.ajax({
				dataType: "jsonp",
				url: queryUrl,
				success: function( _data ) {
					var results = _data.results.bindings;
					sparqlItemsData = _data;
					countChidren += results.length;
					for ( var i in results ) {
						var id =usId+formatInput(results[i].dep.value) + results[i].name2.value ;
						tableContent += '<tr id=\''+id+'\'>';
						tableContent += '<td>' + usId+ '</td>'; 
						 tableContent += '<td>' + formatDependence(results[i].dep.value) + '</td>';
						 tableContent += '<td>' + results[i].name2.value + '</td>';
						 tableContent += '<td><a href=\'#\' class=\'linkdeleteitem\' rel=\'' + usId +";"+formatInput(results[i].dep.value) +";"+ results[i].name2.value  + '\'>delete</a><br>';
						 								 
								 
						 tableContent += '</tr>'
					}
					var query2 = "\PREFIX User-Stories: <http://www.exemple.fr/usersstory.rdfs%23> "+
					  " PREFIX Metier: <http://www.exemple.fr/university.rdfs%23>"+
					  " SELECT ?name  WHERE"+
					  " {"+
					  " ?US User-Stories:isDecomposed{2,} ?US2."+
					  " ?US2 User-Stories:name ?name."+
					  " ?US User-Stories:name '"+usId+"'."+	 
					 "} ";
					 var queryUrl = url+"?query="+query2+"&format=json" ;
					 $.ajax({
						dataType: "jsonp",
						url: queryUrl,
						success: function( _data ) {
							var results = _data.results.bindings;
							sparqlItemsData = _data;
							countChidren += results.length;
							for ( var i in results ) {
								 tableContent += '<td>' + usId+ '</td>';
								 tableContent += '<td> transitive </td>'; 
							     tableContent += '<td>' + results[i].name.value + '</td>'; 	
								 tableContent += '</tr>'
							}
							//alert(tableContent);
							tableContent += '</tbody>'
							if(countChidren > 0){
								$('#sparqlChidrenItemList').html(tableContent);
								$('#sparqlChidrenItemList tbody td a.linkdeleteitem').bind('click', deleteLink);
							} else {
								$('#sparqlChidrenItemList').html('No children.');
							}
						}
					});	
			
					
				}
			});	
	}
	
	function listeFatherDecomps (usId){
		//alert(usId);
		  var tableContent = '';
		  tableContent +='<thead><tr> <br/>\
			<td> Father links</td>\
			</tr></thead>';;
			tableContent += '<tbody>'
		  var countFather = 0;
			<!-- rows will go here -->
		  var url = "http://localhost:3030/data/query";
		  //il ne faut pas mettre le caractere # , mais %23 a la place
		  
			  var query1 = "\PREFIX User-Stories: <http://www.exemple.fr/usersstory.rdfs%23> "+
				  "PREFIX Metier: <http://www.exemple.fr/university.rdfs%23>"+
				  "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema%23>"+
				 " SELECT  ?dep ?name "+
				 " WHERE { "+
				 " ?US ?dep ?US2."+
				 " ?dep rdfs:subPropertyOf User-Stories:isDecomposed."+
				 " ?US2  User-Stories:name  '"+usId+"'."+	 
				 " ?US User-Stories:name ?name."+
				  " FILTER (!regex( str(?dep) ,  'isDecomposed' ))"+
				 "}";
				 
			 var queryUrl = url+"?query="+query1+"&format=json" ;
			 $.ajax({
				dataType: "jsonp",
				url: queryUrl,
				async:   false,
				success: function( _data ) {
					var results = _data.results.bindings;
					sparqlItemsData = _data;
					countFather = results.length;
					for ( var i in results ) {
						 var id =results[i].name.value+formatInput(results[i].dep.value) + usId ;
						 tableContent += '<tr id=\''+id+'\'>';
						 tableContent += '<td>' + results[i].name.value + '</td>';
						 tableContent += '<td>' + formatDependence(results[i].dep.value) + '</td>';
						 tableContent += '<td>' + usId + '</td>'; 
						 tableContent += '<td><a href=\'#\' class=\'linkdeleteitem\' rel=\'' +  results[i].name.value+";"+formatInput(results[i].dep.value) +";"+ usId  + '\'>delete</a><br>';
						 
						 tableContent += '</tr>'
					}
					var query2 = "\PREFIX User-Stories: <http://www.exemple.fr/usersstory.rdfs%23> "+
					  " PREFIX Metier: <http://www.exemple.fr/university.rdfs%23>"+
					  " SELECT ?name  WHERE"+
					  " {"+
					  " ?US User-Stories:isDecomposed{2,} ?US2."+
					  " ?US User-Stories:name ?name."+
					  " ?US2 User-Stories:name '"+usId+"'."+	 
					 "} ";
					 var queryUrl = url+"?query="+query2+"&format=json" ;
					 $.ajax({
						dataType: "jsonp",
						url: queryUrl,
						async:   false,
						success: function( _data ) {
							var results = _data.results.bindings;
							sparqlItemsData = _data;
							countFather += results.length;
							for ( var i in results ) {
								 tableContent += '<tr>';
								 tableContent += '<td>' + results[i].name.value + '</td>'; 								
								 tableContent += '<td> transitive </td>'; 
							     tableContent += '<td>' + usId + '</td>';
								 tableContent += '</tr>'
							}
							//alert(tableContent);	
							tableContent += '</tbody>'
							if(countFather > 0){
								$('#sparqlFatherItemList').html(tableContent);
								$('#sparqlFatherItemList tbody td a.linkdeleteitem').bind('click', deleteLink);
							} else {
								$('#sparqlFatherItemList').html('No father.');
							}
						}
					});	
				}
			});	
	}
	
	function listeDeps(usId){
	var tableContent = '';
		  tableContent +='<thead><tr> <br/>\
			<td> Dependences</td>\
			</tr></thead>';;
			tableContent += '<tbody>'
		  var countDeps = 0;
			<!-- rows will go here -->
		  var url = "http://localhost:3030/data/query";
		  //il ne faut pas mettre le caractere # , mais %23 a la place
		  
			  var query1 = "\PREFIX User-Stories: <http://www.exemple.fr/usersstory.rdfs%23> "+
				  "PREFIX Metier: <http://www.exemple.fr/university.rdfs%23>"+
				  "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema%23>"+
				 " SELECT  ?name1 ?dep ?name2  WHERE  "+
				 " { "+
				 " ?US ?dep ?US2."+
				 " ?dep rdfs:subPropertyOf User-Stories:hasDependence."+
				 " ?US  User-Stories:name ?name1."+
				 " ?US2 User-Stories:name ?name2. "+
				 " FILTER (!regex( str(?dep) ,  'hasDependence' ) %26%26"+
				 " (regex( str(?name2) ,  '"+usId+"' ) || regex( str(?name1) ,  '"+usId+"' )))"+
				 " }";
				 
			 var queryUrl = url+"?query="+query1+"&format=json" ;
			 $.ajax({
				dataType: "jsonp",
				url: queryUrl,
				async:   false,
				success: function( _data ) {
					var results = _data.results.bindings;
					sparqlItemsData = _data;
					countDeps = results.length;
					for ( var i in results ) {
						 var id =results[i].name1.value+formatInput(results[i].dep.value) + results[i].name2.value ;
						 tableContent += '<tr id=\''+id+'\'>';
						 tableContent += '<td>' + results[i].name1.value + '</td>'; 
						 tableContent += '<td>' + formatDependence(results[i].dep.value) + '</td>';
						 tableContent += '<td>' + results[i].name2.value + '</td>';
						 tableContent += '<td><a href=\'#\' class=\'linkdeleteitem\' rel=\'' +  results[i].name1.value+";"+formatInput(results[i].dep.value) +";"+ results[i].name2.value  + '\'>delete</a><br>';
						 
						 tableContent += '</tr>'
					}
					var query2 = "\PREFIX User-Stories: <http://www.exemple.fr/usersstory.rdfs%23> "+
					  " PREFIX Metier: <http://www.exemple.fr/university.rdfs%23>"+
					  " SELECT distinct ?name1 ?name2  WHERE"+
					  " {"+
					  " ?US User-Stories:hasDependence{2,} ?US2."+
					  " ?US  User-Stories:name ?name1."+
					  " ?US2 User-Stories:name ?name2. "+
					  " FILTER (regex( str(?name2) ,  '"+usId+"' ) || regex( str(?name1) ,  '"+usId+"' ))"+
					 "} ";
					 var queryUrl = url+"?query="+query2+"&format=json" ;
					 $.ajax({
						dataType: "jsonp",
						url: queryUrl,
						async:   false,
						success: function( _data ) {
							var results = _data.results.bindings;
							sparqlItemsData = _data;
							countDeps += results.length;
							for ( var i in results ) {
								 tableContent += '<tr>';
								 tableContent += '<td>' + results[i].name1.value + '</td>';
								 tableContent += '<td> transitive </td>'; 
							     tableContent += '<td>' + results[i].name2.value + '</td>'; 								
								 tableContent += '</tr>'
							}
							//alert(tableContent);	
							tableContent += '</tbody>'
							if(countDeps > 0){
								$('#sparqlDepItemList').html(tableContent);
								$('#sparqlDepItemList tbody td a.linkdeleteitem').bind('click', deleteLink);
							} else {
								$('#sparqlDepItemList').html('No dependence.');
							}
						}
					});	
					
				}
			});	
	
	}
	
	function listeDepUS (){
	  <!-- rows will go here -->
	  var url = "http://localhost:3030/data/query";
	  //il ne faut pas mettre le caractere # , mais %23 a la place
	  
	  var query = "\PREFIX User-Stories: <http://www.exemple.fr/usersstory.rdfs%23> "+
		  "PREFIX Metier: <http://www.exemple.fr/university.rdfs%23>"+
		 " SELECT ?name "+
		 " WHERE { "+
		 " ?US  User-Stories:name  ?name;"+
		 "}";
	 var queryUrl = url+"?query="+query+"&format=json" ;
	//alert(queryUrl);

		$.ajax({
		dataType: "jsonp",
		url: queryUrl,
		async:false,
		success: function( _data ) {
			var results = _data.results.bindings;
			$.each(results, function(i, item) {
					$('#selectDepUS1').append($('<option>').text(item.name.value).attr('value', item.name.value));
					$('#selectDepUS2').append($('<option>').text(item.name.value).attr('value', item.name.value));
				});
			}
		});	
	};
	
	function listeDecompUS (){
		  <!-- rows will go here -->
		  var url = "http://localhost:3030/data/query";
		  //il ne faut pas mettre le caractere # , mais %23 a la place
		  
			var query = "\PREFIX User-Stories: <http://www.exemple.fr/usersstory.rdfs%23> "+
		  "PREFIX Metier: <http://www.exemple.fr/university.rdfs%23>"+
		 " SELECT ?name "+
		 " WHERE { "+
		 " ?US  User-Stories:name  ?name;"+
		 " a User-Stories:EpicUserStory"+
		 "}";
		 var queryUrl = url+"?query="+query+"&format=json" ;
		//alert(queryUrl);

			$.ajax({
			dataType: "jsonp",
			url: queryUrl,
			success: function( _data ) {
			var results = _data.results.bindings;
			$.each(results, function(i, item) {
					$('#selectDecompUS1').append($('<option>').text(item.name.value).attr('value', item.name.value));
				});
			}
		});	
		  
		  
		  var query = "\PREFIX User-Stories: <http://www.exemple.fr/usersstory.rdfs%23> "+
		  "PREFIX Metier: <http://www.exemple.fr/university.rdfs%23>"+
		 " SELECT ?name "+
		 " WHERE { "+
		 " ?US  User-Stories:name  ?name;"+
		 "}";
		 var queryUrl = url+"?query="+query+"&format=json" ;
		//alert(queryUrl);

			$.ajax({
			dataType: "jsonp",
			url: queryUrl,
			success: function( _data ) {
			var results = _data.results.bindings;
			$.each(results, function(i, item) {
					$('#selectDecompUS2').append($('<option>').text(item.name.value).attr('value', item.name.value));
				});
			}
			});	
	

};

	
	function formatDependence(dependance){
		return dependance.substring(dependance.indexOf("#")); 
	}
	

